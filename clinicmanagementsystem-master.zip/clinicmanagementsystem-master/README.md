# clinicmanagementsystem
CMS’ is specially designed for general and single clinic. This system allows user to have a better efficiency management of clinic work that can be computerize and have proper patient’s records, appointment reminder and medicine.
